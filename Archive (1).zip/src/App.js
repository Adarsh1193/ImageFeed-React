import React, { Component } from 'react';
import AddImage from './components/AddImage';
import ShowList from './components/showList';


class App extends Component {

  state={
    image:[]
  }

  addMyTask =(task) =>{
    this.setState(state => {
      const list = state.image.push(task);
      return {
        list
      };
    });

  }

  render() {
    let showTask =null;

    showTask = this.state.image.map(data =>{
    return  <ShowList url = {data.url} title={data.title} />
  })

    return (
      <div className="App">
       <AddImage added= {this.addMyTask}/>
       <ul>
         {showTask}
         </ul>
      </div>
    );
  }
}

export default App;
