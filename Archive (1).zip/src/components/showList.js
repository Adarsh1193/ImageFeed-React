import React, {Component} from 'react';

class ShowList extends Component{
    render(){
        return(
            <div>
                <li>
                <img id='image'
      src={this.props.url}
      alt={this.props.title} 
      /></li>
            </div>
    
        )
    }
}
export default ShowList;