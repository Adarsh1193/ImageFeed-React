import React, {Component} from 'react';

class AddImage extends Component{

    addTask =()=>{
        const add_image = {
            url: this.addurl.value,
            title: this.addtitle.value
        }
        this.props.added(add_image); 
    }
    render(){

        return(
            <div>
                <input type="text" id='box1' ref={input =>{this.addurl = (input)}} placeholder="Enter the image url"/><br/>
                <input type="text" id='box2' placeholder="Enter the Title" ref={input =>{this.addtitle = (input)}}/><br/>
                <button  id='box3' onClick={this.addTask}>Add Image</button>
            </div>
    
        )
    }
}
export default AddImage;